# Creator example

In order to run the creator on this example:

```bash
mkdir Output
dotnet run --project ../../src/ARMTemplates create --configFile Input/valid.yml
```